// Background service worker placeholder
